#include "monitor.h"
#include "compra.h"

auto main() -> int
{
	//function();
	monitor();
}
