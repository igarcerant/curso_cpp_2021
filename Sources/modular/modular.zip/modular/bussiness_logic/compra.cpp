#include "compra.h"

void funcion()
{}


