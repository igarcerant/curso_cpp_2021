#ifndef COMPRA_H
#define COMPRA_H 1

void function();

#endif /*COMPRA_H*/

