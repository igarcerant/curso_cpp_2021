#include <iostream>
#include "monitor.h"

using std::cout;
using std::endl;

void monitor()
{
	cout << "hello, world!" << endl;
}

