#ifndef MONITOR_H
#define MONITOR_H 1

void monitor();

#endif /*MONITOR_H*/

